import { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, Copy, Trash2, Radio } from 'lucide-react';

function App() {
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [partialTranscript, setPartialTranscript] = useState('');
  const [statusMessage, setStatusMessage] = useState('Click to start speaking');
  const [isCopied, setIsCopied] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus',
      });
      mediaRecorderRef.current = mediaRecorder;

      const ws = new WebSocket('ws://localhost:8000/transcribe');
      wsRef.current = ws;

      ws.onopen = () => {
        setStatusMessage('Connected - Speak now');
        setIsRecording(true);
        mediaRecorder.start(250);
      };

      ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        if (data.type === 'partial') {
          setPartialTranscript(data.text);
        } else if (data.type === 'final') {
          setTranscript(prev => prev + ' ' + data.text);
          setPartialTranscript('');
        }
      };

      ws.onerror = () => {
        setStatusMessage('Connection error - Check backend');
        stopRecording();
      };

      ws.onclose = () => {
        setStatusMessage('Connection closed');
        stopRecording();
      };

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0 && ws.readyState === WebSocket.OPEN) {
          ws.send(event.data);
        }
      };
    } catch (error) {
      setStatusMessage('Microphone access denied');
      console.error('Error accessing microphone:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach(track => track.stop());
    }
    if (wsRef.current) {
      wsRef.current.close();
    }
    setIsRecording(false);
    setStatusMessage('Stopped');
  };

  const copyToClipboard = () => {
    const fullText = (transcript + ' ' + partialTranscript).trim();
    navigator.clipboard.writeText(fullText);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const clearTranscript = () => {
    setTranscript('');
    setPartialTranscript('');
    setStatusMessage('Click to start speaking');
  };

  useEffect(() => {
    return () => {
      stopRecording();
    };
  }, []);

  const toggleRecording = () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-gradient-to-r from-orange-500 to-orange-600 p-3 rounded-2xl mr-4">
              <Radio className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-5xl font-bold text-white">Maata Lipi</h1>
          </div>
          <p className="text-2xl text-orange-400 mb-2">తెలుగు మాటను లిపి చేయండి</p>
          <p className="text-lg text-blue-200">Convert Telugu Speech to Text in Real-Time</p>
        </header>

        <div className="flex flex-col lg:flex-row gap-6 mb-12">
          <div className="lg:w-1/3 bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 shadow-2xl">
            <h2 className="text-xl font-semibold text-white mb-6 text-center">Input</h2>

            <div className="flex flex-col items-center space-y-6">
              <button
                onClick={toggleRecording}
                className={`w-40 h-40 rounded-full flex items-center justify-center transition-all duration-300 transform hover:scale-105 shadow-2xl ${
                  isRecording
                    ? 'bg-gradient-to-br from-red-500 to-orange-600 animate-pulse'
                    : 'bg-gradient-to-br from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700'
                }`}
              >
                {isRecording ? (
                  <MicOff className="w-20 h-20 text-white" />
                ) : (
                  <Mic className="w-20 h-20 text-white" />
                )}
              </button>

              <div className="text-center">
                <p className="text-white font-medium text-lg">{statusMessage}</p>
                {isRecording && (
                  <div className="flex items-center justify-center mt-2">
                    <span className="w-3 h-3 bg-red-500 rounded-full animate-pulse mr-2"></span>
                    <span className="text-red-400 text-sm">Recording</span>
                  </div>
                )}
              </div>

              <div className="flex gap-3 w-full mt-8">
                <button
                  onClick={copyToClipboard}
                  disabled={!transcript && !partialTranscript}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-colors duration-200"
                >
                  <Copy className="w-5 h-5" />
                  {isCopied ? 'Copied!' : 'Copy'}
                </button>
                <button
                  onClick={clearTranscript}
                  disabled={!transcript && !partialTranscript}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-red-600 hover:bg-red-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-colors duration-200"
                >
                  <Trash2 className="w-5 h-5" />
                  Clear
                </button>
              </div>
            </div>
          </div>

          <div className="lg:w-2/3 bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 shadow-2xl">
            <h2 className="text-xl font-semibold text-white mb-6">Live Transcription</h2>
            <div className="bg-white rounded-xl p-6 min-h-[400px] shadow-inner">
              <div className="text-gray-900 text-lg leading-relaxed whitespace-pre-wrap">
                {transcript && <span className="font-medium">{transcript}</span>}
                {partialTranscript && (
                  <span className="text-gray-500 italic ml-1">{partialTranscript}</span>
                )}
                {!transcript && !partialTranscript && (
                  <p className="text-gray-400 text-center mt-20">Your transcription will appear here...</p>
                )}
              </div>
            </div>
          </div>
        </div>

        <footer className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 shadow-2xl">
          <h2 className="text-2xl font-bold text-white mb-4 text-center">Powered by Advanced Technology</h2>
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div>
              <h3 className="text-orange-400 font-semibold mb-2">Ultra-Low Latency</h3>
              <p className="text-blue-200 text-sm">Streaming Conformer Model for real-time transcription</p>
            </div>
            <div>
              <h3 className="text-orange-400 font-semibold mb-2">High-Quality Training</h3>
              <p className="text-blue-200 text-sm">Trained on premium OpenSLR Telugu datasets</p>
            </div>
            <div>
              <h3 className="text-orange-400 font-semibold mb-2">Maata Lipi ASR</h3>
              <p className="text-blue-200 text-sm">Custom-built Telugu speech recognition engine</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;
